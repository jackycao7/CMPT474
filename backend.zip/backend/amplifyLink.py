
# CHANGE TO YOUR OWN AMPLIFY LINK
amplifyLink = 'https://dev.deycwj94w1425.amplifyapp.com'